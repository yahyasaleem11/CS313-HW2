#include<iostream>
#include<string>
#include<stack>
using namespace std;

double evaluatePrefix(string exp)
{
    stack<int> s; // create a stack

    for (int i = exp.size() - 1; i >-1; i--) {

        // if a digit (operand) is encoutered, push it to stack
        // subtract '0' to convert the character to number
        if (isdigit(exp[i]))
            s.push(exp[i] - '0');
        else {
            // runs if an operator is met
            // get two operands from top of the stack
            // so that we can perform the desired operation
            int o1 = s.top();
            s.pop();
            int o2 = s.top();
            s.pop();
            // perform the indicated operation using switch statement
            switch (exp[i]) {
            case '+':
                // adds the operand and push the result onto stack
                s.push(o1 + o2);
                break;
            case '-':
                // substracts the operand and push the result onto stack
                s.push(o1 - o2);
                break;
            case '*':
                // multiplies the operand and push the result onto stack
                s.push(o1 * o2);
                break;
            case '/':
                // divides the operand and push the result onto stack
                s.push(o1 / o2);
                break;
            }
        }
    }
    // return the top of stack which now represents the result
    return s.top();
}

int main()
{
    // provided the expression for prefix by ourselves
    string exp = "+3*14";
    cout << evaluatePrefix(exp) << endl;
    return 0;
}