#include<iostream>

#define SIZE 20	// size of stack

using namespace std;

// Definiation of Stack
class Stack {
private:
	int	top;	// to represent the top of stack array
	int* arr; // to represent the stack array
public:
	// constructor for class
	// initializes top for stack and also the array with given size
	Stack() {
		top = -1;
		arr = new int[SIZE];
	}
	~Stack() {
		// deletes dynamically allocated memory
		delete arr;
	}
	bool isEmpty() {
		// return if stack is empty
		return top == -1;
	}
	bool isFull() {
		// return true if stack is full
		return top == SIZE;
	}
	void push(int e) {
		// only adds the element to stack if the stack is not yet full
		if (!isFull())	arr[++top] = e;
	}
	int pop() {
		// pops element only if the stack is not empty, and update top
		// otherwise return -1
		if(!isEmpty())	return arr[top--];
		return -1;
	}
	// a. List all elements in stack
	void printStack() {
		// only print stack elements if stack is not empty
		if (!isEmpty()) {
			cout << "Stack elements from top are\n";
			// loop until top >= 0 and prints the element from stack
			for (int i = top; i > -1; i--) {
				cout << arr[i] << " ";
			}
			cout << endl;
		}
		else cout << "Stack is empty" << endl;
	}
	// b. Iterate through the stack and change one of the values based on its position
	// changes element at given position from top - top is 0 position
	void change(int pos, int val) {
		if (pos >= SIZE) {
			// see if position is valid
			cout << "Index out of order" << endl;
		}
		else {
			// change value only if the position is valid
			int idx = 0;
			// loop until we get our desired index - starting from top which is 0
			for (int i = top; i > -1; i--) {
				// change value if we find the required position/index
				if (idx == pos) {
					arr[i] = val;
					// return immediately as our job is done
					return;
				}
				idx++;
			}
			cout << "Index out of order" << endl;
		}
	}
};

int main() {
	// array and linked list based stacks
	Stack s;
	// pushing values to array based stack
	for (int i = 0; i < SIZE; i++) {
		s.push(rand());
	}
	// print stack - a part function
	s.printStack();
	// change value of element based on its position - b part function
	s.change(4,20);	// changes element at 4th index to 20 - 4th index from top, top is 0 index
	// now print stack and see what has changed
	cout << "\n\nStack after changing\n";
	s.printStack();
	return 0;
}