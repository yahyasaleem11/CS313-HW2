#include<iostream>
#include <ctime>

#define SIZE 100000000	// size of 1 million

using namespace std;

// Definiation of Array Based Stack
class ArrayBasedStack {
private:
	int	top;	// to represent the top of stack array
	int* arr; // to represent the stack array
public:
	// constructor for class
	// initializes top for stack and also the array with given size
	ArrayBasedStack() {
		top = -1;
		arr = new int[SIZE];
	}
	~ArrayBasedStack() {
		// deletes dynamically allocated memory
		delete arr;
	}
	bool isEmpty() {
		// return if stack is empty
		return top == -1;
	}
	bool isFull() {
		// return true if stack is full
		return top == SIZE;
	}
	void push(int e) {
		// only adds the element to stack if the stack is not yet full
		if (!isFull())	arr[++top] = e;
	}
	int pop() {
		// pops element only if the stack is not empty, and update top
		// otherwise return -1
		if(!isEmpty())	return arr[top--];
		return -1;
	}
};

class LinkedListBasedStack {
private:
	// class to store the node for linked list
	class Node {
	public:
		int data;	// to store the data
		Node* next;	// to represent the next item in linked list based stack
		// creates a node with give parameters
		Node(int data, Node* next = NULL) {
			this->data = data;
			this->next = next;
		}
	};
	Node* top; // to represent the top of stack
public:
	// set top to null initially
	LinkedListBasedStack() {
		top = NULL;
	}
	// delete the dynamically allocated top node
	~LinkedListBasedStack() {
		delete top;
	}
	bool isEmpty() {
		// return if stack is empty
		return top == NULL;
	}
	void push(int e) {
		// only adds the element to stack
		// incase stack is empty
		// top will be new node
		if (isEmpty()) {
			top = new Node(e);
		}
		// new node will be top and also points to all data that top was representing at start
		else {
			top = new Node(e, top);
		}
	}
	int pop() {
		// pops element only if the stack is not empty, and update top
		// otherwise return -1
		if (!isEmpty()) {
			int v = top->data;
			Node* t = top;
			top = top->next;
			delete t;
			return v;
		}
		return -1;
	}
};

int main() {
	// array and linked list based stacks
	ArrayBasedStack abs;
	LinkedListBasedStack llbs;
	// starting time
	time_t start = time(NULL), end;
	// pushing values to array based stack
	for (int i = 0; i < SIZE; i++) {
		abs.push(rand());
	}
	end = time(NULL);
	// print time it took to push values to array based stack
	cout << "Time to push " << SIZE << " elements to array based stack took " << end - start << " seconds"<<endl;
	start = time(NULL);
	// poping values from array based stack
	for (int i = 0; i < SIZE; i++) {
		abs.pop();
	}
	end = time(NULL);
	// print time it took to pop values from array based stack
	cout << "Time to pop " << SIZE << " elements from array based stack took " << end - start << " seconds" << endl;
	start = time(NULL);
	// pushing values to linked list based stack
	for (int i = 0; i < SIZE; i++) {
		llbs.push(rand());
	}
	end = time(NULL);
	// print time it took to push to linked list based stack
	cout << "Time to push " << SIZE << " elements to linked list based stack took " << end - start << " seconds" << endl;
	start = time(NULL);
	// pop values from linked list based stack
	for (int i = 0; i < SIZE; i++) {
		llbs.pop();
	}
	end = time(NULL);
	// time it took to pop values from linked list based stack
	cout << "Time to pop " << SIZE << " elements from linked list based stack took " << end - start << " seconds" << endl;
	return 0;
}